import numpy as np
from joblib import Parallel, delayed
from scipy.interpolate import UnivariateSpline
from sklearn.svm import SVC
from sklearn.utils import Bunch
from DataframeToSklearn import load_pima, load_heart
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, AdaBoostClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.ticker as mtick

LABEL_IDX = 0
PRED_IDX = 1

# 加载数据集
# breast_data = load_breast_cancer()
# pima_data = load_pima()
heart_data = load_heart()


def compareRepeat(baseline_result, pred_result) -> np.ndarray:
    def single_run(pred_idx, baseline_result, pred_result):
        different_count = np.sum(baseline_result != pred_result[pred_idx])
        return different_count

    res_list = Parallel(n_jobs=-1)(
        delayed(single_run)(pred_idx=i, baseline_result=baseline_result, pred_result=pred_result) for i in
        range(len(pred_result)))
    return np.vstack(res_list)


def evaluate_model(model, X, y, k_folds=5, n_jobs=-1):
    def single_run(train_index, test_index, model, X, y):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        return y_pred

    X = np.array(X)
    y = np.array(y)

    skf = StratifiedKFold(n_splits=k_folds)
    results = Parallel(n_jobs=n_jobs)(
        delayed(single_run)(train_index, test_index, model, X, y) for train_index, test_index in skf.split(X, y))
    max_length = max(len(arr) for arr in results)
    padded_results = [np.pad(arr, (0, max_length - len(arr)), 'constant') for arr in results]

    return np.vstack(padded_results)


# 加载数据集
# data = load_breast_cancer()
# data = load_pima()
data = load_heart()

svm = SVC(kernel='rbf')
svm_results = evaluate_model(svm, data.data, data.target, k_folds=5, n_jobs=-1)[0]

eva_list = []

#最大深度
max_depths = [1, 2, 3, 4, 5]
for i in max_depths:
    # RF
    #classifier = RandomForestClassifier(max_depth=i, random_state=23)
    # ET
    classifier = ExtraTreesClassifier(max_depth=i, random_state=23)
    # TRF
    #classifier = RandomForestClassifier(max_depth=i, random_state=42, bootstrap=False, max_features=None)

    #ADRF
    #classifier = AdaBoostClassifier(estimator=RandomForestClassifier(max_depth=i, random_state=23),
    # n_estimators=5, random_state=42)

    results = evaluate_model(classifier, data.data, data.target, k_folds=5, n_jobs=-1)
    different_res = compareRepeat(svm_results, results)
    eva_list.append(different_res.mean() / len(data.target) * 100)

# #基分类器数量
# n_estimators = [10, 20, 30, 40, 50]
#
# for i in n_estimators:
#     # RF
#     #classifier = RandomForestClassifier(n_estimators=i, random_state=23)
#     # ET
#     classifier = ExtraTreesClassifier(n_estimators=i, random_state=23)
#     # TRF
#     #classifier = RandomForestClassifier(n_estimators=i, random_state=42, bootstrap=False, max_features=None)
#
#     #ADRF
#     #classifier = AdaBoostClassifier(estimator=RandomForestClassifier(n_estimators=i, random_state=23),
#     # n_estimators=5, random_state=42)
#
#     results = evaluate_model(classifier, data.data, data.target, k_folds=5, n_jobs=-1)
#     different_res = compareRepeat(svm_results, results)
#     eva_list.append(different_res.mean() / len(data.target) * 100)


# 画图
plt.figure(figsize=(6, 6))
colors = sns.color_palette("viridis", len(eva_list))

plt.bar(x=[i for i in range(1, len(eva_list) + 1)], height=eva_list, width=1, color=colors)

x = np.array([i for i in range(1, len(eva_list) + 1)])
y = np.array(eva_list)
# 创建一元样条插值函数
spl = UnivariateSpline(x, y)

# 创建新的x值
xnew = np.linspace(x.min(), x.max(), 500)

# 计算新的y值
ynew = spl(xnew)
# 绘制平滑后的折线图
plt.plot(xnew, ynew, color='blue')

# 将每个样本点标注出来
plt.scatter(x, y, color='blue')

#plt.gca().axes.get_xaxis().set_visible(False)  # 隐藏x坐标轴
fmt = '%.2f%%'  # 定义百分比格式，保留2位小数
yticks = mtick.FormatStrFormatter(fmt)
plt.gca().yaxis.set_major_formatter(yticks)
plt.ylim(bottom=3.8)

for i, v in enumerate(eva_list):
    plt.text(i + 1, v + 0.03, f"{v:.3f}%", ha='center', va='top')

# 设置标题和轴标签
plt.title('Different Sample Percentage(ET)', fontsize=16)
plt.xlabel('Max Depth', fontsize=14)
#plt.ylabel('Percentage (%)', fontsize=14)

# 增大刻度字体大小
plt.tick_params(labelsize=12)

# 显示图形
plt.show()
