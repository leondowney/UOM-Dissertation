import pandas as pd
from sklearn.utils import Bunch
import numpy as np


def load_pima():
    """
    加载Pima Indians糖尿病数据集，并将其转换为sklearn.utils.Bunch对象。

    :return Bunch: 包含数据、目标、描述、特征名称和目标名称的Bunch对象。
    """
    df = pd.read_csv("./Pima Indians.csv")

    # 创建Bunch对象并填充数据
    sk_pima = Bunch()
    sk_pima.data = _get_data(df)
    sk_pima.target = _get_target(df)
    sk_pima.DESCR = _get_descr("Pima Indians", df)
    sk_pima.feature_names = _get_feature_names(df)
    sk_pima.target_names = _get_target_names(df)

    return sk_pima


def load_heart():
    """
    加载心脏病数据集，并将其转换为sklearn.utils.Bunch对象。

    :return Bunch: 包含数据、目标、描述、特征名称和目标名称的Bunch对象。
    """
    columns = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach", "exang", "oldpeak", "slope", "ca",
               "thal", "target"]
    df = pd.read_csv("./processed.cleveland.data", names=columns)

    # 创建Bunch对象并填充数据
    sk_heart = Bunch()
    sk_heart.data = _get_data(df)
    sk_heart.target = _get_target(df)
    sk_heart.DESCR = _get_descr("heart diseases", df)
    sk_heart.feature_names = _get_feature_names(df)
    sk_heart.target_names = _get_target_names(df)

    return sk_heart


def _get_data(df):
    """

    :param df: df (DataFrame): 包含数据的DataFrame。
    :return: numpy.ndarray: 包含特征数据的NumPy数组。
    """

    data_r = df.iloc[:, 0:len(df.columns) - 1]
    data_np = np.array(data_r, dtype=np.float64)
    return data_np


def _get_target(df):
    """
    提取数据集中的目标标签。
    :param df: df (DataFrame): 包含数据的DataFrame。
    :return: numpy.ndarray: 包含目标标签的NumPy数组。
    """
    target_r = df.iloc[:, len(df.columns) - 1]
    target_np = np.array(target_r, dtype=np.int32)
    return target_np


def _get_descr(dataset_name, df):
    """
    生成数据集的描述信息。
    :param dataset_name: 数据集的名称。
    :param df: 包含数据的DataFrame。
    :return: 描述数据集的字符串。
    """
    text = "{}，样本数量：{}；".format(dataset_name, len(df))
    return text


def _get_feature_names(df):
    """

    :param df: df (DataFrame): 包含数据的DataFrame。
    :return: list: 特征名称的列表。
    """

    feature_names = df.columns[:-1].tolist()
    return feature_names


def _get_target_names(df):
    """

    :param df: df (DataFrame): 包含数据的DataFrame。
    :return: list: 标签名称的列表。
    """
    target_names = [df.columns[-1]]
    return target_names
